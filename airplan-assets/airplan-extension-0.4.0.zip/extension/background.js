importScripts('model.js','config.js');
const terminal=['ready','error','stopped'];
const providerHost={eva:['booking.evaair.com'],cathay:['www.cathaypacific.com','book.cathaypacific.com']};
const state=async()=> (await chrome.storage.local.get('search')).search;
const allowed = sender => {
 try {
  if(sender.id===chrome.runtime.id && sender.url===chrome.runtime.getURL('popup.html'))return true;
  const u=new URL(sender.url);
  return u.origin===AIRPLAN_ORIGIN||u.origin==='http://localhost:4173'||(['https://toolist.cc','https://www.toolist.cc'].includes(u.origin)&&['/airplan','/airplan/','/airplan.html'].includes(u.pathname));
 }catch{return false;}
};
let queue=Promise.resolve();
function serial(fn){const p=queue.then(fn);queue=p.catch(()=>{});return p;}
async function start(q){
  q=Airplan.validateJourney(q);const previous=await state();
  const providers={};
  for(const [leg,query] of Object.entries(Airplan.legs(q)))for(const provider of ['eva','cathay']){
    providers[provider+(leg==='inbound'?'Return':'')]={provider,leg,query,status:'running',phase:'form',message:'正在開啟官網…',rows:[]};
  }
  const search={id:crypto.randomUUID(),query:q,startedAt:Date.now(),providers};
  // Invalidate the previous task before navigating any provider tab.
  await chrome.storage.local.set({search});
  for(const [key,p] of Object.entries(search.providers)){
    const provider=p.provider;const url=provider==='eva'?Airplan.evaURL:Airplan.cathayURL(p.query);
    let tab;const oldId=previous?.providers[key]?.tabId;
    if(oldId){try{const old=await chrome.tabs.get(oldId);if(providerHost[provider].includes(new URL(old.url).hostname))tab=await chrome.tabs.update(oldId,{url,active:false});}catch{}}
    if(!tab)tab=await chrome.tabs.create({url,active:false});
    search.providers[key].tabId=tab.id;
    await chrome.storage.local.set({search});
  }
  return search;
}
chrome.runtime.onMessage.addListener((m,sender,reply)=>{
  serial(async()=>{
    if(['PING','START','STATE','STOP','FOCUS'].includes(m.type)){
      if(!allowed(sender))throw Error('未授權的網站。');
      if(m.type==='PING')return {version:chrome.runtime.getManifest().version};
      if(m.type==='START')return start(m.query);
      const search=await state();
      if(m.type==='STOP'&&search){for(const p of Object.values(search.providers)){if(!terminal.includes(p.status)){p.status='stopped';p.message='已停止';}}await chrome.storage.local.set({search});}
      if(m.type==='FOCUS'&&search?.providers[m.provider]?.tabId)await chrome.tabs.update(search.providers[m.provider].tabId,{active:true});
      return search||null;
    }
    if(!['TASK','UPDATE'].includes(m.type)||!sender.tab)return null;
    const search=await state();if(!search)return null;
    const entry=Object.entries(search.providers).find(([p,v])=>v.tabId===sender.tab.id&&providerHost[v.provider||p].includes(new URL(sender.url).hostname));
    if(!entry)return null;const [provider,p]=entry;
    if(Date.now()-search.startedAt>15*60000&&!terminal.includes(p.status)){p.status='error';p.message='搜尋已超過 15 分鐘，請重新搜尋。';await chrome.storage.local.set({search});}
    if(m.type==='TASK')return terminal.includes(p.status)?null:{id:search.id,...p,query:p.query||search.query,provider:p.provider||provider};
    if(m.id!==search.id||terminal.includes(p.status))return null;
    const patch=m.patch||{};
    if(patch.phase)p.phase=String(patch.phase).slice(0,30);
    if(['running','login','attention','ready','error'].includes(patch.status))p.status=patch.status;
    if(patch.message)p.message=String(patch.message).slice(0,500);
    if(Array.isArray(patch.rows))p.rows=patch.rows.slice(0,200).map(r=>({date:String(r.date||''),flight:String(r.flight||'').slice(0,200),status:['available','waitlist','unavailable','unknown','mixed'].includes(r.status)?r.status:'unknown',miles:Number.isFinite(r.miles)?r.miles:null,milesSource:r.milesSource==='chart'?'chart':'live',note:String(r.note||'').slice(0,500)}));
    p.checkedAt=new Date().toISOString();await chrome.storage.local.set({search});return {ok:true};
  }).then(value=>reply({value}),error=>reply({error:error.message}));return true;
});
