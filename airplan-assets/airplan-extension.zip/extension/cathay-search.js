(() => {
 const {text,visible,$,all}=AP;let busy=false;
 const cabinMatch=(label,cabin)=>cabin==='business'?/商務/.test(label):cabin==='premium'?/特選|豪華/.test(label):/經濟/.test(label)&&!/特選|豪華/.test(label);
 async function tick(){if(busy)return;busy=true;let t;
  try{
   t=await AP.send({type:'TASK'});if(!t||t.provider!=='cathay'||t.status==='attention')return;const q=t.query;
   if(location.hostname==='www.cathaypacific.com'){
    const button=$('#flight-booking-search-btn');
    if(!button||/登入/.test(text(button))){if(t.status!=='login')await AP.update(t,{status:'login',message:'請在國泰分頁登入，登入後會接續搜尋。'});return;}
    if(t.phase!=='form')return;
    const origin=await AP.wait(()=>all('input[role="combobox"]').find(el=>visible(el)&&el.value.includes(q.origin)),30000);
    const dest=all('input[role="combobox"]').find(el=>visible(el)&&el.value.includes(q.destination));
    const expected=q.date.replace(/(\d{4})-(\d{2})-(\d{2})/,'$1年$2月$3日');
    const calendar=all('button').find(el=>visible(el)&&text(el).includes(expected));
    const cabin=all('[role="combobox"]').find(el=>visible(el)&&text(el).includes('客艙級別及乘客'));
    const single=all('[role="tab"]').find(el=>text(el)==='單程'&&el.getAttribute('aria-selected')==='true');
    if(!origin||!dest||!calendar||!single||!cabinMatch(text(cabin),q.cabin)||!text(cabin).includes(`${q.passengers} 成人`))throw Error('國泰未完整帶入搜尋條件，請在官網確認條件後按兌換機票，結果會在這裡接收。');
    if(!await AP.current(t))return;
    await AP.update(t,{phase:'submitted',status:'running',message:'國泰查詢中…'});button.click();return;
   }
   if(location.hostname!=='book.cathaypacific.com'||!location.pathname.endsWith('/availability'))return;
   const scope=await AP.wait(()=>$('.col-select-departure-flight'),45000);
   // Ignore partial renders: the selected cabin and matching date must be present.
   await AP.wait(()=>!all('img[alt="Loading"]').some(visible)&&scope.querySelector('.cabin-ticket-card-wrapper-outer.active'),45000);
   const actualDate=Airplan.normalizeDate(text($('.row-flight-details-inner .col-depart')));
   const pax=text($('.flight-details-pax'));
   if(actualDate!==q.date||pax!==String(q.passengers)||$('.row-flight-details-inner .col-return'))throw Error('國泰回傳的日期、人數或單程條件不一致，已停止。');
   const current=scope.querySelector('.cabin-ticket-card-wrapper-outer.active');
   if(!cabinMatch(text(current.querySelector('.cabin-class')),q.cabin)){
    const desired=[...scope.querySelectorAll('.cabin-ticket-card-wrapper-outer')].find(el=>visible(el)&&el.getAttribute('aria-disabled')!=='true'&&cabinMatch(text(el.querySelector('.cabin-class')),q.cabin));
    if(!desired)throw Error('此結果沒有指定艙等選項，請在官網確認。');desired.click();await AP.sleep(1500);return;
   }
   const cards=[...scope.querySelectorAll('.row-flight-card')].filter(visible);
   const rows=cards.flatMap(el=>{
    const origin=text(el.querySelector('.col-origin-time abbr')),destination=text(el.querySelector('.col-dest-time abbr'));
    if(origin!==q.origin||destination!==q.destination)return [];
    const notice=el.querySelector('.col-flight-notice');
    const note=visible(notice)?notice.innerText.trim():'';
    const milesText=text(el.querySelector('.am-total')).replaceAll(',','');
    const miles=/^\d+$/.test(milesText)?Number(milesText):null;
    const disabled=el.getAttribute('aria-disabled')==='true'||el.classList.contains('flight-full')||el.classList.contains('inactive');
    const waitlist=el.classList.contains('flight-card-waitlist');
    const mixed=/客艙級別|混合|mixed/i.test(note);
    return [{date:q.date,flight:(el.getAttribute('data-flight-name')||'').replaceAll('_',' + ')+` ${text(el.querySelector('.depart-time'))} → ${text(el.querySelector('.arrival-time'))}`,status:Airplan.cxStatus({disabled,waitlist,mixed}),miles,milesSource:'live',note:note||'官網單程／每人報價，未含稅費。'}];
   });
   if(rows.length){await AP.update(t,{status:'ready',rows,message:'已取得亞洲萬里通航班及里數（包含官網回傳的合作航空）。'});return;}
   const noFlights=[...scope.querySelectorAll('h2')].some(el=>visible(el)&&text(el).includes('沒有可供選擇的航班'));
   if(noFlights){await AP.update(t,{status:'ready',rows:[],message:'國泰官網顯示此日此艙等沒有可供選擇的航班。'});return;}
   throw Error(cards.length?'官網回傳其他機場的航班；尚未確認指定機場的可兌換機位。':'尚未讀到完整國泰票位結果，請開啟官網確認。');
  }catch(e){if(t)await AP.update(t,{status:'attention',message:e.message});}
  finally{busy=false;}
 }
 setInterval(tick,1500);tick();
})();
