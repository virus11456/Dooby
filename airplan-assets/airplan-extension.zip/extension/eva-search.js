(() => {
 const {text,visible,$,all}=AP;let busy=false;
 async function airport(selector,code){
   const field=$(selector);field.focus();AP.set(field,code);
   const option=await AP.wait(()=>all('li').find(el=>visible(el)&&text(el).endsWith(' - '+code)&&el.children.length<3));
   option.click();await AP.sleep(250);
   if(!field.value.includes(code))throw Error('無法確認機場 '+code);
 }
 async function date(value){
   const [y,m,d]=value.split('-');
   const alt=all('input.js-DateGo').find(el=>visible(el));if(!alt)throw Error('找不到長榮日期欄位。');alt.click();
   const year=await AP.wait(()=>all('select[aria-label="年"]').find(visible));AP.set(year,y);await AP.sleep(200);
   const month=all('select[aria-label="月"]').find(visible);AP.set(month,String(Number(m)-1));await AP.sleep(200);
   const day=await AP.wait(()=>all('[aria-label]').find(el=>visible(el)&&el.getAttribute('aria-label')===`${y}年${m}月${d}日`&&!el.classList.contains('flatpickr-disabled')));day.click();
   const done=all('button').find(el=>visible(el)&&text(el)==='完成');if(done)done.click();
 }
 async function tick(){if(busy)return;busy=true;let t;
  try{
   t=await AP.send({type:'TASK'});if(!t||t.provider!=='eva'||t.status==='attention')return;
   if(!$('#content_txt_formcity')){if(t.status!=='login')await AP.update(t,{status:'login',message:'請在長榮分頁登入並完成驗證碼，登入後會接續搜尋。'});return;}
   const q=t.query;
   if(t.phase==='form'){
    await AP.wait(()=>all('input.js-DateGo').find(visible));
    await AP.update(t,{status:'running',message:'正在填入長榮查詢條件…'});
    $('#content_Radio_Award').click();$('#content_Radio_OneWay').click();
    await airport('#content_txt_formcity',q.origin);await airport('#content_txt_tocity',q.destination);
    AP.set($('#content_ddl_Award_Cabin'),{economy:'EY',premium:'PE',business:'SD'}[q.cabin]);AP.set($('#content_ddl_PassengerCount'),String(q.passengers));await date(q.date);
    if(!await AP.current(t))return;
    await AP.update(t,{phase:'submitted',status:'running',message:'長榮查詢中…'});$('#content_btn_ok').click();return;
   }
   if(t.phase==='submitted'){
    const result=await AP.wait(()=>$('#content_control_Award_AvailabilityGO_div_Result'),45000);
    if(!$('#content_Radio_Award')?.checked||!$('#content_Radio_OneWay')?.checked)throw Error('官網不是單程酬賓機位查詢。');
    if(!$('#content_txt_formcity').value.includes(q.origin)||!$('#content_txt_tocity').value.includes(q.destination)||$('#content_ddl_PassengerCount').value!==String(q.passengers)||$('#content_ddl_Award_Cabin').value!=={economy:'EY',premium:'PE',business:'SD'}[q.cabin])throw Error('官網條件與本次搜尋不同，已停止以避免錯誤結果。');
    const rows=[...result.querySelectorAll('tbody tr')].flatMap(tr=>{
     const flight=text(tr.querySelector('th'));if(!/BR\d+|B7\d+/.test(flight))return [];
     return [...tr.querySelectorAll('td[aria-label]')].filter(td=>Airplan.normalizeDate(td.getAttribute('aria-label'))===q.date).map(td=>({date:q.date,flight,status:td.querySelector('img')?.alt==='尚有機位'?'available':td.querySelector('img')?.alt==='候補'?'waitlist':'unknown',miles:Airplan.evaMiles(q),milesSource:'chart',note:'單程／每人，依官方兌換表；未含稅費。'}));
    });
    if(!rows.length)throw Error('未讀取到指定日期的票位表；請在官網確認，不代表沒有機位。');
    await AP.update(t,{status:'ready',rows,message:'已取得長榮指定日期票位。'});
   }
  }catch(e){if(t)await AP.update(t,{status:'attention',message:e.message});}
  finally{busy=false;}
 }
 setInterval(tick,1300);tick();
})();
