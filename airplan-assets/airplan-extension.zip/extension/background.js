importScripts('model.js','config.js');
const terminal=['ready','error','stopped','skipped'];
const providerHost={eva:['booking.evaair.com'],cathay:['www.cathaypacific.com','book.cathaypacific.com']};
const state=async()=> (await chrome.storage.local.get('search')).search;
const allowed = sender => {
 try {
  if(sender.id===chrome.runtime.id && sender.url===chrome.runtime.getURL('popup.html'))return true;
  const u=new URL(sender.url);
  return u.origin===AIRPLAN_ORIGIN||u.origin==='http://localhost:4173'||(['https://toolist.cc','https://www.toolist.cc'].includes(u.origin)&&['/airplan','/airplan/','/airplan.html'].includes(u.pathname));
 }catch{return false;}
};
let queue=Promise.resolve();
function serial(fn){const p=queue.then(fn);queue=p.catch(()=>{});return p;}
async function advance(search){
 for(const provider of ['eva','cathay'])for(const leg of ['outbound','inbound']){
  const lane=Object.values(search.providers).filter(p=>p.provider===provider&&p.leg===leg);
  if(lane.some(p=>['running','login','attention'].includes(p.status)))continue;
  const next=lane.find(p=>p.status==='queued');if(!next)continue;
  const prior=[...lane].reverse().find(p=>p.tabId);
  const url=provider==='eva'?Airplan.evaURL:Airplan.cathayURL(next.query);
  next.status='running';next.message='正在開啟官網…';
  // Persist invalidation before navigation; each date has its own task ID.
  if(prior)delete prior.tabId;
  await chrome.storage.local.set({search});
  try{
   let tab;
   const tabId=search.laneTabs?.[provider+leg];
   if(tabId){try{const old=await chrome.tabs.get(tabId);if(providerHost[provider].includes(new URL(old.url).hostname))tab=await chrome.tabs.update(tabId,{url,active:false});}catch{}}
   if(!tab)tab=await chrome.tabs.create({url,active:false});
   next.tabId=tab.id;search.laneTabs||={};search.laneTabs[provider+leg]=tab.id;
  }catch(e){next.status='error';next.message='無法開啟官網：'+e.message;}
  await chrome.storage.local.set({search});
 }
}
async function start(q){
 q=Airplan.validateJourney(q);
 const search={id:crypto.randomUUID(),query:q,startedAt:Date.now(),providers:Object.fromEntries(Airplan.calendarJobs(q).map(({key,...p})=>[key,p]))};
 await chrome.storage.local.set({search});await advance(search);return search;
}
chrome.runtime.onMessage.addListener((m,sender,reply)=>{
  serial(async()=>{
    if(['PING','START','STATE','STOP','FOCUS'].includes(m.type)){
      if(!allowed(sender))throw Error('未授權的網站。');
      if(m.type==='PING')return {version:chrome.runtime.getManifest().version};
      if(m.type==='START')return start(m.query);
      const search=await state();
      if(m.type==='STOP'&&search){for(const p of Object.values(search.providers)){if(!terminal.includes(p.status)){p.status='stopped';p.message='已停止';}}await chrome.storage.local.set({search});}
      if(m.type==='FOCUS'&&search){const p=search.providers[m.provider]||Object.values(search.providers).find(p=>p.provider===m.provider&&p.tabId);if(p?.tabId)await chrome.tabs.update(p.tabId,{active:true});}
      return search||null;
    }
    if(!['TASK','UPDATE'].includes(m.type)||!sender.tab)return null;
    const search=await state();if(!search)return null;
    const entry=Object.entries(search.providers).find(([p,v])=>v.tabId===sender.tab.id&&providerHost[v.provider||p].includes(new URL(sender.url).hostname));
    if(!entry)return null;const [provider,p]=entry;
    if(Date.now()-search.startedAt>15*60000&&!terminal.includes(p.status)){p.status='error';p.message='搜尋已超過 15 分鐘，請重新搜尋。';await chrome.storage.local.set({search});}
    if(m.type==='TASK')return terminal.includes(p.status)?null:{id:search.id+':'+provider,...p,query:p.query||search.query,provider:p.provider||provider};
    if(m.id!==search.id+':'+provider||terminal.includes(p.status))return null;
    const patch=m.patch||{};
    if(patch.phase)p.phase=String(patch.phase).slice(0,30);
    if(['running','login','attention','ready','error'].includes(patch.status))p.status=patch.status;
    if(patch.message)p.message=String(patch.message).slice(0,500);
    if(Array.isArray(patch.rows))p.rows=patch.rows.slice(0,200).map(r=>({date:String(r.date||''),flight:String(r.flight||'').slice(0,200),status:['available','waitlist','unavailable','unknown','mixed'].includes(r.status)?r.status:'unknown',miles:Number.isFinite(r.miles)?r.miles:null,milesSource:r.milesSource==='chart'?'chart':'live',note:String(r.note||'').slice(0,500)}));
    p.checkedAt=new Date().toISOString();await chrome.storage.local.set({search});if(terminal.includes(p.status))await advance(search);return {ok:true};
  }).then(value=>reply({value}),error=>reply({error:error.message}));return true;
});
