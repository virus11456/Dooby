globalThis.AP={
  $:s=>document.querySelector(s),
  all:s=>[...document.querySelectorAll(s)],
  text:el=>el?.textContent.replace(/\s+/g,' ').trim()||'',
  visible:el=>!!el&&el.getClientRects().length>0&&getComputedStyle(el).visibility!=='hidden',
  sleep:ms=>new Promise(r=>setTimeout(r,ms)),
  async send(m){const r=await chrome.runtime.sendMessage(m);if(r?.error)throw Error(r.error);return r?.value;},
  async wait(fn,ms=20000){const until=Date.now()+ms;while(Date.now()<until){const v=fn();if(v)return v;await this.sleep(250);}throw Error('官網欄位或結果載入逾時；請開啟官網確認登入與查詢條件。');},
  set(el,value){if(!el)throw Error('官網欄位已變更');const setter=Object.getOwnPropertyDescriptor(el.tagName==='SELECT'?HTMLSelectElement.prototype:HTMLInputElement.prototype,'value').set;setter.call(el,value);el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));},
  async update(task,patch){return this.send({type:'UPDATE',id:task.id,patch});},
  async current(task){const now=await this.send({type:'TASK'});return now?.id===task.id;}
};
