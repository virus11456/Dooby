importScripts('model.js','config.js');
const terminal=['ready','error','stopped','skipped'];
const providerHost={eva:['booking.evaair.com'],cathay:['www.cathaypacific.com','book.cathaypacific.com']};
const state=async()=> (await chrome.storage.local.get('search')).search;
const allowed = sender => {
 try {
  if(sender.id===chrome.runtime.id && sender.url===chrome.runtime.getURL('popup.html'))return true;
  const u=new URL(sender.url);
  return u.origin===AIRPLAN_ORIGIN||u.origin==='http://localhost:4173'||(['https://toolist.cc','https://www.toolist.cc'].includes(u.origin)&&['/airplan','/airplan/','/airplan.html'].includes(u.pathname));
 }catch{return false;}
};
let queue=Promise.resolve();
function serial(fn){const p=queue.then(fn);queue=p.catch(()=>{});return p;}
async function advance(search){
 for(const provider of ['eva','cathay'])for(const leg of ['outbound','inbound']){
  const lane=Object.values(search.providers).filter(p=>p.provider===provider&&p.leg===leg);
  if(lane.some(p=>['running','login','attention'].includes(p.status)))continue;
  const center=leg==='inbound'?search.query.returnDate:search.query.date;const next=lane.find(p=>p.status==='queued'&&p.query.date===center)||lane.find(p=>p.status==='queued');if(!next)continue;
  const prior=[...lane].reverse().find(p=>p.tabId);
  const url=provider==='eva'?Airplan.evaURL:Airplan.cathayURL(next.query);
  next.attempt=(next.attempt||0)+1;next.taskStartedAt=Date.now();next.status='running';next.message='正在開啟官網…';
  // Persist invalidation before navigation; each date has its own task ID.
  if(prior){if(prior.documentId){search.retiredDocuments||=[];search.retiredDocuments.push(prior.documentId);}delete prior.tabId;}
  await chrome.storage.local.set({search});
  try{
   let tab;
   const tabId=search.laneTabs?.[provider+leg];
   if(tabId){try{const old=await chrome.tabs.get(tabId);if(providerHost[provider].includes(new URL(old.url).hostname))tab=await chrome.tabs.update(tabId,{url,active:false});}catch{}}
   if(!tab)tab=await chrome.tabs.create({url,active:false});
   next.tabId=tab.id;search.laneTabs||={};search.laneTabs[provider+leg]=tab.id;
  }catch(e){next.status='error';next.message='無法開啟官網：'+e.message;}
  await chrome.storage.local.set({search});
 }
}
async function start(q){
 q=Airplan.validateJourney(q);const previous=await state();
 const search={id:crypto.randomUUID(),query:q,startedAt:Date.now(),laneTabs:previous?.laneTabs||{},retiredDocuments:Object.values(previous?.providers||{}).map(p=>p.documentId).filter(Boolean),providers:Object.fromEntries(Airplan.calendarJobs(q).map(({key,...p})=>[key,p]))};
 await chrome.storage.local.set({search});await advance(search);return search;
}
chrome.runtime.onMessage.addListener((m,sender,reply)=>{
  serial(async()=>{
    if(['PING','START','STATE','STOP','FOCUS','RETRY'].includes(m.type)){
      if(!allowed(sender))throw Error('未授權的網站。');
      if(m.type==='PING')return {version:chrome.runtime.getManifest().version};
      if(m.type==='START')return start(m.query);
      const search=await state();
      if(m.type==='STATE'&&search){
       for(const p of Object.values(search.providers)){
        if(p.status==='running'&&Date.now()-(p.taskStartedAt||search.startedAt)>120000){p.status='error';p.message='此日查詢逾時，請重試。';}
        if(['running','login','attention'].includes(p.status)&&p.tabId){try{await chrome.tabs.get(p.tabId);}catch{p.status='error';p.message='航空分頁已關閉，請重試。';}}
       }
       await chrome.storage.local.set({search});await advance(search);
      }
      if(m.type==='RETRY'&&search){const p=search.providers[m.provider];if(!p)throw Error('找不到查詢日期。');if(['error','attention','stopped'].includes(p.status)){p.status='queued';p.phase='form';p.rows=[];p.message='等待重新查詢';await chrome.storage.local.set({search});await advance(search);}}
      if(m.type==='STOP'&&search){for(const p of Object.values(search.providers)){if(!terminal.includes(p.status)){p.status='stopped';p.message='已停止';}}await chrome.storage.local.set({search});}
      if(m.type==='FOCUS'&&search){const p=search.providers[m.provider]||Object.values(search.providers).find(p=>p.provider===m.provider&&p.tabId);if(p?.tabId)await chrome.tabs.update(p.tabId,{active:true});}
      return search||null;
    }
    if(!['TASK','UPDATE'].includes(m.type)||!sender.tab)return null;
    const search=await state();if(!search||search.retiredDocuments?.includes(sender.documentId))return null;
    const entry=Object.entries(search.providers).find(([p,v])=>v.tabId===sender.tab.id&&providerHost[v.provider||p].includes(new URL(sender.url).hostname));
    if(!entry)return null;const [provider,p]=entry;
    if(Date.now()-(p.taskStartedAt||search.startedAt)>120000&&p.status!=='login'&&!terminal.includes(p.status)){p.status='error';p.message='此日查詢逾時，請重試。';await chrome.storage.local.set({search});}
    if(m.type==='TASK'&&sender.documentId){p.documentId=sender.documentId;await chrome.storage.local.set({search});}
    if(m.type==='TASK')return terminal.includes(p.status)?null:{id:search.id+':'+provider+':'+(p.attempt||1),...p,query:p.query||search.query,provider:p.provider||provider};
    if(m.id!==search.id+':'+provider+':'+(p.attempt||1)||terminal.includes(p.status))return null;
    const patch=m.patch||{};
    if(patch.phase)p.phase=String(patch.phase).slice(0,30);
    if(['running','login','attention','ready','error'].includes(patch.status)){if(p.status==='login'&&patch.status==='running')p.taskStartedAt=Date.now();p.status=patch.status;}
    if(patch.message)p.message=String(patch.message).slice(0,500);
    if(Array.isArray(patch.rows)){const rows=patch.rows.slice(0,200).map(r=>({date:String(r.date||''),flight:String(r.flight||'').slice(0,200),status:['available','waitlist','unavailable','unknown','mixed'].includes(r.status)?r.status:'unknown',miles:Number.isFinite(r.miles)?r.miles:null,milesSource:r.milesSource==='chart'?'chart':'live',note:String(r.note||'').slice(0,500)}));
     p.rows=rows.filter(row=>row.date===p.query.date);
     if(patch.status==='ready'&&rows.length&&!p.rows.length){p.status='error';p.message='回傳日期與查詢不同，未採用此結果。';}
     if(p.provider==='eva'&&patch.status==='ready')for(const other of Object.values(search.providers)){
      if(other.provider!=='eva'||other.leg!==p.leg||other.status!=='queued')continue;
      const matching=rows.filter(row=>row.date===other.query.date);if(!matching.length)continue;
      other.rows=matching;other.status='ready';other.message='長榮官網七天票位表';other.checkedAt=new Date().toISOString();
     }
    }
    p.checkedAt=new Date().toISOString();await chrome.storage.local.set({search});if(terminal.includes(p.status))await advance(search);return {ok:true};
  }).then(value=>reply({value}),error=>reply({error:error.message}));return true;
});
