// Restricted by the manifest to the exact Airplan origin and localhost.
window.addEventListener('message',async event=>{
  if(event.source!==window||event.origin!==location.origin||event.data?.source!=='airplan-web')return;
  const {id,type,query,provider}=event.data;
  if(typeof id!=='string'||!['PING','START','STATE','STOP','FOCUS','RETRY'].includes(type))return;
  try{const response=await chrome.runtime.sendMessage({type,query,provider});window.postMessage({source:'airplan-extension',id,...response},location.origin);}
  catch(e){window.postMessage({source:'airplan-extension',id,error:e.message},location.origin);}
});

window.postMessage({source:'airplan-extension',type:'READY'},location.origin);
