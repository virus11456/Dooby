(() => {
 const {text,visible,$,all}=AP;let busy=false;
 const cabinMatch=(label,cabin)=>cabin==='business'?/商務/.test(label):cabin==='premium'?/特選|豪華/.test(label):/經濟/.test(label)&&!/特選|豪華/.test(label);
 async function tick(){if(busy)return;busy=true;let t;
  try{
   t=await AP.send({type:'TASK'});if(!t||t.provider!=='cathay'||(t.status==='attention'&&location.hostname==='www.cathaypacific.com'))return;const q=t.query;
   if(location.hostname==='www.cathaypacific.com'){
    const button=await AP.wait(()=>{const b=$('#flight-booking-search-btn');return visible(b)&&b;},30000);
    if(!button||/登入/.test(text(button)+' '+button.getAttribute('aria-label'))){if(t.status!=='login')await AP.update(t,{status:'login',message:'請在國泰分頁登入，登入後會接續搜尋。'});return;}
    if(t.phase!=='form')return;
    const url=new URL(location.href);
    if(t.status==='login'&&url.searchParams.get('DEPARTUREDATE[1]')!==q.date.replaceAll('-','')){await AP.update(t,{status:'running',message:'登入完成，正在還原搜尋條件…'});location.assign(Airplan.cathayURL(q));return;}

    const ready=await AP.wait(()=>{
     const current=$('#flight-booking-search-btn');
     if(current&&/登入/.test(text(current)+' '+current.getAttribute('aria-label')))return {login:true};
     const origin=all('input[role="combobox"]').find(el=>visible(el)&&el.value.includes(q.origin));
     const dest=all('input[role="combobox"]').find(el=>visible(el)&&el.value.includes(q.destination));
     const calendar=all('button').find(el=>visible(el)&&Airplan.normalizeDate(text(el))===q.date);
     const cabin=all('[role="combobox"]').find(el=>visible(el)&&text(el).includes('客艙級別及乘客'));
     const single=all('[role="tab"]').find(el=>text(el)==='單程'&&el.getAttribute('aria-selected')==='true');
     return origin&&dest&&calendar&&single&&cabinMatch(text(cabin),q.cabin)&&text(cabin).includes(`${q.passengers} 成人`)&&current&&!current.disabled&&/兌換機票/.test(text(current)+' '+current.getAttribute('aria-label'))&&{button:current};
    },30000);
    if(ready.login){await AP.update(t,{status:'login',message:'請在國泰分頁登入，登入後會接續搜尋。'});return;}
    if(!await AP.current(t))return;
    await AP.update(t,{phase:'submitted',status:'running',message:'國泰查詢中…'});ready.button.click();return;
   }
   if(location.hostname!=='book.cathaypacific.com'||!location.pathname.endsWith('/availability'))return;
   const scope=await AP.wait(()=>$('.col-select-departure-flight'),45000);
   // Ignore partial renders: the selected cabin and matching date must be present.
   await AP.wait(()=>!all('img[alt="Loading"]').some(visible)&&scope.querySelector('.cabin-ticket-card-wrapper-outer.active'),45000);
   const actualDate=Airplan.normalizeDate(text($('.row-flight-details-inner .col-depart')));
   const pax=text($('.flight-details-pax'));
   if(actualDate!==q.date||pax!==String(q.passengers)||$('.row-flight-details-inner .col-return'))throw Error('國泰回傳的日期、人數或單程條件不一致，已停止。');
   const current=scope.querySelector('.cabin-ticket-card-wrapper-outer.active');
   if(!cabinMatch(text(current.querySelector('.cabin-class')),q.cabin)){
    const desired=[...scope.querySelectorAll('.cabin-ticket-card-wrapper-outer')].find(el=>visible(el)&&el.getAttribute('aria-disabled')!=='true'&&cabinMatch(text(el.querySelector('.cabin-class')),q.cabin));
    if(!desired)throw Error('此結果沒有指定艙等選項，請在官網確認。');desired.click();await AP.sleep(1500);return;
   }
   const cards=[...scope.querySelectorAll('.row-flight-card')].filter(visible);
   const rows=cards.flatMap(el=>{
    const origin=text(el.querySelector('.col-origin-time abbr')),destination=text(el.querySelector('.col-dest-time abbr'));
    if(origin!==q.origin||destination!==q.destination)return [];
    const notice=el.querySelector('.col-flight-notice');
    const note=visible(notice)?notice.innerText.trim():'';
    const milesText=text(el.querySelector('.am-total')).replaceAll(',','');
    const miles=/^\d+$/.test(milesText)?Number(milesText):null;
    const disabled=el.getAttribute('aria-disabled')==='true'||el.classList.contains('flight-full')||el.classList.contains('inactive');
    const waitlist=el.classList.contains('flight-card-waitlist');
    const mixed=/客艙級別|混合|mixed/i.test(note);
    return [{date:q.date,flight:(el.getAttribute('data-flight-name')||'').replaceAll('_',' + ')+` ${text(el.querySelector('.depart-time'))} → ${text(el.querySelector('.arrival-time'))}`,status:Airplan.cxStatus({disabled,waitlist,mixed}),miles,milesSource:'live',note:note||'官網單程／每人報價，未含稅費。'}];
   });
   if(rows.length){await AP.update(t,{status:'ready',rows,message:'已取得亞洲萬里通航班及里數（包含官網回傳的合作航空）。'});return;}
   const noFlights=[...scope.querySelectorAll('h2')].some(el=>visible(el)&&text(el).includes('沒有可供選擇的航班'));
   if(noFlights){await AP.update(t,{status:'ready',rows:[],message:'國泰官網顯示此日此艙等沒有可供選擇的航班。'});return;}
   throw Error(cards.length?'官網回傳其他機場的航班；尚未確認指定機場的可兌換機位。':'尚未讀到完整國泰票位結果，請開啟官網確認。');
  }catch(e){if(t)await AP.update(t,{status:'error',message:e.message});}
  finally{busy=false;}
 }
 setInterval(tick,1500);tick();
})();
