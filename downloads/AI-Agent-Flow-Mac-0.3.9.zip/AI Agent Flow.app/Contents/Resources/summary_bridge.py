#!/usr/bin/env python3
"""Configure a quota-only Claude Code status line without accessing credentials."""
import argparse
import json
import os
from pathlib import Path
import shlex
import time

from collector import atomic_json, DEFAULT_STATE


def configure(action, settings=None, state=None, collector=None):
    settings = settings or Path.home() / '.claude/settings.json'
    state = state or DEFAULT_STATE
    collector = collector or Path(__file__).with_name('collector.py').resolve()
    command = '/usr/bin/python3 ' + shlex.quote(str(collector)) + ' --statusline'
    try:
        original = settings.read_bytes() if settings.exists() else None
        data = json.loads(original) if original is not None else {}
        if not isinstance(data, dict):
            raise ValueError()
        current = data.get('statusLine')
        ours = isinstance(current, dict) and current.get('command') == command
        if action == 'connect':
            if current is not None and not ours:
                return {'success': False, 'message': '已有其他 Claude 狀態列，未覆蓋。請依 GitHub 說明整合摘要來源。'}
            data['statusLine'] = {'type': 'command', 'command': command}
        elif action == 'disconnect':
            if current is not None and not ours:
                return {'success': False, 'message': '狀態列已由其他工具變更，未修改。'}
            data.pop('statusLine', None)
        else:
            raise ValueError()
        # Do not overwrite a concurrently edited settings file.
        if (settings.read_bytes() if settings.exists() else None) != original:
            return {'success': False, 'message': 'Claude 設定剛被修改，請稍後再試。'}
        if original is not None and not ours:
            backup = settings.with_name('settings.before-aiflow-' + str(time.time_ns()) + '.json')
            fd = os.open(backup, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, 'wb') as handle:
                handle.write(original)
        atomic_json(settings, data)
        if action == 'disconnect':
            (state / 'claude-status.json').unlink(missing_ok=True)
        return {'success': True, 'message': '已連接。請在 Claude Code 完成一次對話；收到官方摘要後更新。' if action == 'connect' else '已停止 Claude 官方摘要連接。'}
    except (OSError, ValueError, TypeError):
        return {'success': False, 'message': '無法安全更新 Claude 設定；原有設定未主動覆蓋。'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['connect', 'disconnect'])
    args = parser.parse_args()
    print(json.dumps(configure(args.action), ensure_ascii=False))
