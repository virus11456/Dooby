#!/usr/bin/env python3
"""Read-only quota collector. Only allowlisted usage fields leave this process."""
import argparse
import concurrent.futures
import datetime as dt
import json
import math
import os
from pathlib import Path
import queue
import shutil
import subprocess
import sys
import tempfile
import threading
import time

DEFAULT_STATE = Path.home() / 'Library/Application Support/AI Agent Flow'


class UsageError(Exception):
    pass


def number(value):
    if isinstance(value, bool) or value is None:
        return None
    try:
        result = float(value)
        return result if math.isfinite(result) else None
    except (TypeError, ValueError):
        return None


def timestamp(value):
    numeric = number(value)
    if numeric is not None:
        return numeric if 0 < numeric < 100000000000 else None
    if isinstance(value, str):
        try:
            parsed = dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
            return parsed.timestamp() if parsed.tzinfo is not None else None
        except ValueError:
            pass
    return None


def row(key, label, used, reset):
    used = number(used)
    return {'id': key, 'label': str(label)[:100],
            'remainingPercent': None if used is None else max(0, min(100, 100-used)),
            'resetsAt': timestamp(reset)}


def duration_label(minutes):
    minutes = number(minutes)
    if minutes == 10080:
        return '每週'
    if minutes == 300:
        return '本次時段'
    if minutes is None:
        return '額度'
    if minutes >= 1440:
        return f'{minutes / 1440:g} 天'
    if minutes >= 60:
        return f'{minutes / 60:g} 小時'
    return f'{minutes:g} 分鐘'


def codex_rows(payload):
    multi = payload.get('rateLimitsByLimitId')
    buckets = multi if isinstance(multi, dict) and multi else {'codex': payload.get('rateLimits')}
    rows = []
    for bucket_id, bucket in buckets.items():
        if not isinstance(bucket, dict):
            continue
        title = bucket.get('limitName') or ('' if bucket_id == 'codex' else bucket_id)
        for name in ('primary', 'secondary'):
            window = bucket.get(name)
            if isinstance(window, dict):
                label = ' · '.join(filter(None, [title, duration_label(window.get('windowDurationMins'))]))
                rows.append(row(f'{bucket_id}:{name}', label, window.get('usedPercent'), window.get('resetsAt')))
    return rows


def plan_label(value, tier=None):
    # Export a display label only, never arbitrary credential/account fields.
    labels = {'free': 'Free', 'plus': 'Plus', 'pro': 'Pro', 'max': 'Max',
              'team': 'Team', 'business': 'Business', 'enterprise': 'Enterprise',
              'edu': 'Edu', 'go': 'Go'}
    plan = labels.get(value.lower()) if isinstance(value, str) else None
    if plan == 'Max':
        plan = {'default_claude_max_5x': 'Max (5x)',
                'default_claude_max_20x': 'Max (20x)'}.get(tier, plan)
    return plan


def codex_plan(payload):
    buckets = payload.get('rateLimitsByLimitId') or {}
    primary = payload.get('rateLimits') or {}
    for bucket in [buckets.get('codex'), primary] + list(buckets.values()):
        if isinstance(bucket, dict):
            label = plan_label(bucket.get('planType'))
            if label:
                return label
    return None


def claude_rows(payload):
    labels = {'five_hour': '本次時段', 'seven_day': '每週',
              'seven_day_opus': 'Opus 每週', 'seven_day_sonnet': 'Sonnet 每週',
              'seven_day_fable': 'Fable 每週'}
    rows = []
    for key, label in labels.items():
        window = payload.get(key)
        if isinstance(window, dict):
            used = window.get('utilization', window.get('used_percentage'))
            rows.append(row(key, label, used, window.get('resets_at')))
    # New scoped model limits, including Fable. No invented limits if absent.
    for i, limit in enumerate(payload.get('limits') or []):
        if not isinstance(limit, dict) or limit.get('is_active') is False:
            continue
        scope = limit.get('scope') or {}
        model = scope.get('model') or {}
        name = model.get('display_name') or model.get('id')
        kind = str(limit.get('kind') or '')
        group = str(limit.get('group') or '')
        if name:
            label = str(name) + (' 每週' if 'weekly' in kind or group == 'weekly' else ' 額度')
        elif 'weekly' in kind or group == 'weekly':
            label = '每週'
        elif 'session' in kind or 'five_hour' in kind or group == 'session':
            label = '本次時段'
        else:
            continue
        rows = [r for r in rows if r['label'].casefold() != label.casefold()]
        rows.append(row(f'limit:{i}', label, limit.get('percent'), limit.get('resets_at')))
    return rows


def find_codex():
    candidates = [os.environ.get('AIAGENTFLOW_CODEX'), shutil.which('codex'),
                  '/Applications/ChatGPT.app/Contents/Resources/codex',
                  '/Applications/Codex.app/Contents/Resources/codex',
                  '/opt/homebrew/bin/codex', '/usr/local/bin/codex']
    for item in candidates:
        if item and Path(item).is_file() and os.access(item, os.X_OK):
            return item
    raise UsageError('請先安裝 Codex 並登入 ChatGPT 訂閱帳號。')


def rpc_codex():
    # Do not create a thread or turn: querying account limits consumes no model tokens.
    process = subprocess.Popen([find_codex(), 'app-server', '--listen', 'stdio://'],
                               stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                               stderr=subprocess.DEVNULL, text=True)
    messages = queue.Queue()

    def reader():
        for line in process.stdout:
            try:
                messages.put(json.loads(line))
            except ValueError:
                continue
        messages.put(None)

    threading.Thread(target=reader, daemon=True).start()

    def send(message):
        process.stdin.write(json.dumps(message) + '\n')
        process.stdin.flush()

    def receive(request_id):
        deadline = time.monotonic() + 25
        while time.monotonic() < deadline:
            try:
                message = messages.get(timeout=max(.01, deadline-time.monotonic()))
            except queue.Empty:
                break
            if message is None:
                raise UsageError('Codex 連線已結束，請確認 Codex 已登入。')
            if message.get('id') == request_id:
                if 'error' in message:
                    raise UsageError('Codex 查詢失敗，請開啟 Codex 確認登入與網路。')
                return message.get('result') or {}
            # No credentials, approvals, or server-side work are delegated to this collector.
            if 'id' in message and 'method' in message:
                send({'id': message['id'], 'error': {'code': -32601, 'message': 'Read-only client'}})
        raise UsageError('Codex 查詢逾時，請確認網路後重試。')

    try:
        send({'id': 1, 'method': 'initialize', 'params': {'clientInfo': {
            'name': 'aiagentflow_usage', 'title': 'AI Agent Flow', 'version': '0.1.0'}}})
        receive(1)
        send({'method': 'initialized'})
        send({'id': 2, 'method': 'account/rateLimits/read'})
        return receive(2)
    finally:
        if process.poll() is None:
            process.terminate()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
        for pipe in (process.stdin, process.stdout):
            pipe.close()


def atomic_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.usage-', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'w') as handle:
            json.dump(data, handle, ensure_ascii=False, allow_nan=False)
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def read_json(path):
    try:
        with open(path) as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def provider(key, label, rows, source, message='', updated=None, status=None, plan=None):
    return {'id': key, 'name': label, 'rows': rows, 'source': source, 'message': message,
            'plan': plan, 'updatedAt': updated, 'status': status or ('ok' if rows else 'unavailable')}


def collect(state):
    previous = read_json(state / 'usage.json')
    old = {p['id']: p for p in previous.get('providers', []) if isinstance(p, dict) and 'id' in p}

    def codex():
        payload = rpc_codex()
        rows = codex_rows(payload)
        return provider('codex', 'OpenAI 工作額度', rows, 'Codex',
                        'Codex・Work・Workspace Agents・Excel 共用；不含一般 Chat 聊天。', time.time(), plan=codex_plan(payload))

    def claude():
        snapshot = read_json(state / 'claude-status.json')
        rows = claude_rows(snapshot.get('rate_limits') or {})
        updated = number(snapshot.get('updatedAt'))
        now = time.time()
        stale = bool(rows) and (updated is None or now - updated > 3600 or
                                any(r['resetsAt'] is not None and r['resetsAt'] <= now for r in rows))
        message = ('等待 Claude Code 新摘要；顯示上次資料。' if stale else
                   '官方摘要；僅在 Claude Code 收到回應後提供資料。' if rows else
                   '等待 Claude Code 官方摘要；請設定摘要連接並在 Claude Code 完成一次對話。')
        return provider('claude', 'Claude', rows, 'Claude Code 官方摘要', message,
                        updated, status='stale' if stale else 'ok' if rows else 'unavailable')

    def guarded(key, name, operation):
        try:
            return operation()
        except Exception as error:
            message = str(error) if isinstance(error, UsageError) else '暫時無法取得資料，請稍後重試。'
            cached = old.get(key)
            if cached and cached.get('rows'):
                return dict(cached, status='stale', message=message)
            return provider(key, name, [], '', message, status='error')

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        a = pool.submit(guarded, 'codex', 'OpenAI 工作額度', codex)
        b = pool.submit(guarded, 'claude', 'Claude', claude)
        providers = [a.result(), b.result()]
    result = {'schemaVersion': 1, 'generatedAt': time.time(), 'providers': providers}
    atomic_json(state / 'usage.json', result)
    return result


def statusline(state, payload):
    limits = payload.get('rate_limits') if isinstance(payload, dict) else None
    safe = {}
    if not isinstance(limits, dict):
        return 'Claude 額度暫無資料'
    for key in ('five_hour', 'seven_day'):
        value = limits.get(key)
        if isinstance(value, dict):
            used = number(value.get('used_percentage'))
            reset = timestamp(value.get('resets_at'))
            if used is not None and 0 <= used <= 100 and reset is not None:
                safe[key] = {'used_percentage': used, 'resets_at': reset}
    if safe:
        # Receive time, not proof of a fresh server query. The CLI owns authentication.
        atomic_json(state / 'claude-status.json', {'rate_limits': safe, 'updatedAt': time.time()})
    # Deliberately do not persist the rest of the status-line payload (paths, prompts, etc.).
    return ' · '.join(f"{r['label']} 剩 {r['remainingPercent']:g}%" for r in claude_rows(safe)
                      if r['remainingPercent'] is not None) or 'Claude 額度暫無資料'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--state-dir', type=Path, default=DEFAULT_STATE)
    parser.add_argument('--statusline', action='store_true')
    args = parser.parse_args()
    if args.statusline:
        try:
            print(statusline(args.state_dir, json.load(sys.stdin)))
        except (ValueError, TypeError, AttributeError):
            print('Claude 額度暫無資料')
    else:
        print(json.dumps(collect(args.state_dir), ensure_ascii=False, allow_nan=False))


if __name__ == '__main__':
    main()
