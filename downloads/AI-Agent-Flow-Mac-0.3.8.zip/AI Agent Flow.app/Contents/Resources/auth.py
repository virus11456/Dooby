#!/usr/bin/env python3
"""Official CLI authentication bridge. Never return raw CLI output or credentials."""
import argparse
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

from collector import find_codex, UsageError


def find_claude():
    for path in (os.environ.get('AIAGENTFLOW_CLAUDE'), shutil.which('claude'),
                 str(Path.home() / '.local/bin/claude'), '/opt/homebrew/bin/claude',
                 '/usr/local/bin/claude'):
        if path and Path(path).is_file() and os.access(path, os.X_OK):
            return path
    raise UsageError('請先安裝 Claude Code，再回來按登入。')


def command(provider, action):
    if provider == 'codex':
        return [find_codex(), 'login'] + (['status'] if action == 'status' else [])
    if provider == 'claude':
        return [find_claude(), 'auth', action] + (['--claudeai'] if action == 'login' else [])
    raise ValueError('Unknown provider')


def clean_environment():
    env = dict(os.environ)
    # This UI explicitly signs in to subscriptions, not API billing.
    for key in ('OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'CLAUDE_CODE_OAUTH_TOKEN'):
        env.pop(key, None)
    return env


def normalize_status(provider, code, output):
    if provider == 'codex':
        subscription = code == 0 and 'logged in using chatgpt' in output.lower()
        logged_in = code == 0
    else:
        try:
            value = json.loads(output)
            logged_in = value.get('loggedIn') is True and code == 0
            subscription = logged_in and value.get('authMethod') == 'claude.ai'
        except (ValueError, AttributeError):
            logged_in = subscription = False
    return {'installed': True, 'loggedIn': subscription,
            'message': '訂閱帳號已登入' if subscription else
                       ('目前不是訂閱登入，請重新登入' if logged_in else '尚未登入訂閱帳號')}


def status(provider):
    try:
        result = subprocess.run(command(provider, 'status'), capture_output=True, text=True,
                                timeout=15, env=clean_environment())
        output = (result.stdout + result.stderr) if provider == 'codex' else result.stdout
        return normalize_status(provider, result.returncode, output)
    except UsageError as error:
        return {'installed': False, 'loggedIn': False, 'message': str(error)}
    except (OSError, subprocess.TimeoutExpired):
        return {'installed': True, 'loggedIn': False, 'message': '無法確認登入狀態，請重試。'}


def login(provider):
    process = None
    cancelled = False

    def stop(signum=None, frame=None):
        nonlocal cancelled
        cancelled = True
        if process is not None and process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass

    old_handler = signal.signal(signal.SIGTERM, stop)
    try:
        process = subprocess.Popen(command(provider, 'login'), stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, text=True,
                                   start_new_session=True, env=clean_environment())
        # CLI owns the browser launch, callback and credential store. Discard output.
        deadline = time.monotonic() + 600
        while not cancelled and time.monotonic() < deadline:
            try:
                process.communicate(timeout=0.25)
                break
            except subprocess.TimeoutExpired:
                continue
        else:
            was_cancelled = cancelled
            stop()
            try:
                process.communicate(timeout=3)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.communicate()
            return {'success': False, 'message': '已取消登入。' if was_cancelled else '登入已逾時，請再試一次。'}
        if cancelled:
            return {'success': False, 'message': '已取消登入。'}
        if process.returncode != 0:
            return {'success': False, 'message': '登入未完成，請確認瀏覽器授權後再試。'}
        current = status(provider)
        return {'success': current['loggedIn'], 'message': current['message']}
    except UsageError as error:
        return {'success': False, 'message': str(error)}
    except OSError:
        return {'success': False, 'message': '無法啟動官方登入工具。'}
    finally:
        signal.signal(signal.SIGTERM, old_handler)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['status', 'login'])
    parser.add_argument('--provider', choices=['codex', 'claude'])
    args = parser.parse_args()
    if args.action == 'status':
        print(json.dumps({key: status(key) for key in ('codex', 'claude')}, ensure_ascii=False))
    elif args.provider:
        print(json.dumps(login(args.provider), ensure_ascii=False))
    else:
        parser.error('--provider is required for login')


if __name__ == '__main__':
    main()
