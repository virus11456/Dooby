#!/usr/bin/env python3
"""Read-only quota collector. Only allowlisted usage fields leave this process."""
import argparse
import concurrent.futures
import datetime as dt
from email.utils import parsedate_to_datetime
import json
import math
import os
from pathlib import Path
import queue
import shutil
import socket
import ssl
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request

DEFAULT_STATE = Path.home() / 'Library/Application Support/AI Agent Flow'


class UsageError(Exception):
    pass


class RateLimited(UsageError):
    def __init__(self, retry_after=None):
        super().__init__('Claude 暫時限制查詢，請稍後再試。')
        self.retry_after = retry_after


def retry_after_seconds(value, now):
    seconds = number(value)
    if seconds is not None:
        return max(0, seconds)
    try:
        date = parsedate_to_datetime(value)
        return max(0, date.timestamp() - now) if date.tzinfo else None
    except (TypeError, ValueError, OverflowError):
        return None


def number(value):
    if isinstance(value, bool) or value is None:
        return None
    try:
        result = float(value)
        return result if math.isfinite(result) else None
    except (TypeError, ValueError):
        return None


def timestamp(value):
    numeric = number(value)
    if numeric is not None:
        return numeric if 0 < numeric < 100000000000 else None
    if isinstance(value, str):
        try:
            parsed = dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
            return parsed.timestamp() if parsed.tzinfo is not None else None
        except ValueError:
            pass
    return None


def row(key, label, used, reset):
    used = number(used)
    return {'id': key, 'label': str(label)[:100],
            'remainingPercent': None if used is None else max(0, min(100, 100-used)),
            'resetsAt': timestamp(reset)}


def duration_label(minutes):
    minutes = number(minutes)
    if minutes == 10080:
        return '每週'
    if minutes == 300:
        return '本次時段'
    if minutes is None:
        return '額度'
    if minutes >= 1440:
        return f'{minutes / 1440:g} 天'
    if minutes >= 60:
        return f'{minutes / 60:g} 小時'
    return f'{minutes:g} 分鐘'


def codex_rows(payload):
    multi = payload.get('rateLimitsByLimitId')
    buckets = multi if isinstance(multi, dict) and multi else {'codex': payload.get('rateLimits')}
    rows = []
    for bucket_id, bucket in buckets.items():
        if not isinstance(bucket, dict):
            continue
        title = bucket.get('limitName') or ('' if bucket_id == 'codex' else bucket_id)
        for name in ('primary', 'secondary'):
            window = bucket.get(name)
            if isinstance(window, dict):
                label = ' · '.join(filter(None, [title, duration_label(window.get('windowDurationMins'))]))
                rows.append(row(f'{bucket_id}:{name}', label, window.get('usedPercent'), window.get('resetsAt')))
    return rows


def plan_label(value, tier=None):
    # Export a display label only, never arbitrary credential/account fields.
    labels = {'free': 'Free', 'plus': 'Plus', 'pro': 'Pro', 'max': 'Max',
              'team': 'Team', 'business': 'Business', 'enterprise': 'Enterprise',
              'edu': 'Edu', 'go': 'Go'}
    plan = labels.get(value.lower()) if isinstance(value, str) else None
    if plan == 'Max':
        plan = {'default_claude_max_5x': 'Max (5x)',
                'default_claude_max_20x': 'Max (20x)'}.get(tier, plan)
    return plan


def codex_plan(payload):
    buckets = payload.get('rateLimitsByLimitId') or {}
    primary = payload.get('rateLimits') or {}
    for bucket in [buckets.get('codex'), primary] + list(buckets.values()):
        if isinstance(bucket, dict):
            label = plan_label(bucket.get('planType'))
            if label:
                return label
    return None


def claude_rows(payload):
    labels = {'five_hour': '本次時段', 'seven_day': '每週',
              'seven_day_opus': 'Opus 每週', 'seven_day_sonnet': 'Sonnet 每週',
              'seven_day_fable': 'Fable 每週'}
    rows = []
    for key, label in labels.items():
        window = payload.get(key)
        if isinstance(window, dict):
            used = window.get('utilization', window.get('used_percentage'))
            rows.append(row(key, label, used, window.get('resets_at')))
    # New scoped model limits, including Fable. No invented limits if absent.
    for i, limit in enumerate(payload.get('limits') or []):
        if not isinstance(limit, dict) or limit.get('is_active') is False:
            continue
        scope = limit.get('scope') or {}
        model = scope.get('model') or {}
        name = model.get('display_name') or model.get('id')
        kind = str(limit.get('kind') or '')
        group = str(limit.get('group') or '')
        if name:
            label = str(name) + (' 每週' if 'weekly' in kind or group == 'weekly' else ' 額度')
        elif 'weekly' in kind or group == 'weekly':
            label = '每週'
        elif 'session' in kind or 'five_hour' in kind or group == 'session':
            label = '本次時段'
        else:
            continue
        rows = [r for r in rows if r['label'].casefold() != label.casefold()]
        rows.append(row(f'limit:{i}', label, limit.get('percent'), limit.get('resets_at')))
    return rows


def find_codex():
    candidates = [os.environ.get('AIAGENTFLOW_CODEX'), shutil.which('codex'),
                  '/Applications/ChatGPT.app/Contents/Resources/codex',
                  '/Applications/Codex.app/Contents/Resources/codex',
                  '/opt/homebrew/bin/codex', '/usr/local/bin/codex']
    for item in candidates:
        if item and Path(item).is_file() and os.access(item, os.X_OK):
            return item
    raise UsageError('請先安裝 Codex 並登入 ChatGPT 訂閱帳號。')


def rpc_codex():
    # Do not create a thread or turn: querying account limits consumes no model tokens.
    process = subprocess.Popen([find_codex(), 'app-server', '--listen', 'stdio://'],
                               stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                               stderr=subprocess.DEVNULL, text=True)
    messages = queue.Queue()

    def reader():
        for line in process.stdout:
            try:
                messages.put(json.loads(line))
            except ValueError:
                continue
        messages.put(None)

    threading.Thread(target=reader, daemon=True).start()

    def send(message):
        process.stdin.write(json.dumps(message) + '\n')
        process.stdin.flush()

    def receive(request_id):
        deadline = time.monotonic() + 25
        while time.monotonic() < deadline:
            try:
                message = messages.get(timeout=max(.01, deadline-time.monotonic()))
            except queue.Empty:
                break
            if message is None:
                raise UsageError('Codex 連線已結束，請確認 Codex 已登入。')
            if message.get('id') == request_id:
                if 'error' in message:
                    raise UsageError('Codex 查詢失敗，請開啟 Codex 確認登入與網路。')
                return message.get('result') or {}
            # No credentials, approvals, or server-side work are delegated to this collector.
            if 'id' in message and 'method' in message:
                send({'id': message['id'], 'error': {'code': -32601, 'message': 'Read-only client'}})
        raise UsageError('Codex 查詢逾時，請確認網路後重試。')

    try:
        send({'id': 1, 'method': 'initialize', 'params': {'clientInfo': {
            'name': 'aiagentflow_usage', 'title': 'AI Agent Flow', 'version': '0.1.0'}}})
        receive(1)
        send({'method': 'initialized'})
        send({'id': 2, 'method': 'account/rateLimits/read'})
        return receive(2)
    finally:
        if process.poll() is None:
            process.terminate()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
        for pipe in (process.stdin, process.stdout):
            pipe.close()


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def renew_claude_if_needed(credentials):
    expiry = number(credentials.get('expiresAt'))
    if expiry is None or expiry > (time.time() + 60) * 1000:
        return False
    helper = Path(__file__).with_name('ClaudeRefresh')
    if not helper.is_file():
        raise UsageError('Claude 憑證已到期；請更新 Mac App 以啟用自動續期。')
    try:
        result = subprocess.run([str(helper)], capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.TimeoutExpired):
        raise UsageError('Claude 自動續期暫時失敗，下次更新會再試。') from None
    if result.returncode == 5:
        raise RateLimited(number(result.stdout.strip()))
    messages = {
        2: 'Claude 續期憑證已失效，請在帳號登入重新登入一次。',
        3: 'Claude 自動續期暫時失敗，下次更新會再試。',
        4: 'Claude 鑰匙圈無法讀取或儲存，請解鎖鑰匙圈並允許存取。',
        6: 'Claude 登入正在更新，下次查詢會使用新的憑證。',
    }
    if result.returncode != 0:
        raise UsageError(messages.get(result.returncode, messages[3]))
    return True


def read_claude_credentials():
    # Never propagate process output or exception text: either may contain secrets.
    try:
        result = subprocess.run(['/usr/bin/security', 'find-generic-password', '-s',
                                 'Claude Code-credentials', '-w'], capture_output=True,
                                text=True, timeout=20)
    except subprocess.TimeoutExpired:
        raise UsageError('Claude 鑰匙圈讀取逾時；登入狀態未確認，下次更新會再試。') from None
    except OSError:
        raise UsageError('Claude 無法啟動鑰匙圈讀取；請檢查系統存取權限。') from None
    if result.returncode:
        raise UsageError('Claude 鑰匙圈讀取失敗；請檢查鑰匙圈存取權限及 Claude Code 登入狀態。')
    try:
        payload = json.loads(result.stdout)
        credentials = payload.get('claudeAiOauth') if isinstance(payload, dict) else None
        if not isinstance(credentials, dict):
            raise ValueError()
    except (ValueError, TypeError):
        raise UsageError('Claude 鑰匙圈資料格式無法辨識；不是用量服務的連線錯誤。') from None
    token = credentials.get('accessToken')
    if not isinstance(token, str) or not token:
        raise UsageError('Claude 鑰匙圈未包含可用憑證；請在 Claude Code 完成登入。')
    return credentials


def native_claude_usage(helper):
    try:
        result = subprocess.run([str(helper), '--usage'], capture_output=True, text=True, timeout=55)
    except subprocess.TimeoutExpired:
        raise UsageError('Claude 原生查詢逾時；請確認是否有待處理的鑰匙圈允許提示。') from None
    except OSError:
        raise UsageError('Claude 原生查詢工具無法啟動，請重新安裝 Mac App。') from None
    if result.returncode == 5:
        raise RateLimited(number(result.stdout.strip()))
    messages = {
        2: 'Claude 續期憑證已失效，請重新登入。',
        3: 'Claude 自動續期暫時失敗，下次更新會再試。',
        4: 'Claude 原生鑰匙圈存取失敗；請解鎖鑰匙圈並允許 ClaudeRefresh 存取。',
        6: 'Claude 登入正在更新，下次查詢會使用新的憑證。',
        7: 'Claude 用量服務拒絕目前憑證（HTTP 401）；若持續發生，請重新登入。',
        8: 'Claude 不允許此用量查詢（HTTP 403）；不代表帳號已登出。',
        9: 'Claude 用量查詢逾時；不代表登出，下次更新會再試。',
        10: 'Claude TLS 連線驗證失敗；請檢查系統時間與網路憑證。',
        11: 'Claude 網域解析失敗；請檢查網路或 DNS。',
        12: 'Claude 用量服務連線失敗；下次更新會再試。',
        13: 'Claude 用量服務暫時無法取得資料；下次更新會再試。',
        14: 'Claude 用量回覆格式不符；保留登入，下次更新會再試。',
    }
    if result.returncode:
        raise UsageError(messages.get(result.returncode, 'Claude 原生查詢未完成；保留上次資料。'))
    try:
        payload = json.loads(result.stdout)
        if not isinstance(payload, dict): raise ValueError()
    except (ValueError, TypeError):
        raise UsageError(messages[14]) from None
    payload['_plan'] = plan_label(payload.pop('_subscriptionType', None), payload.pop('_rateLimitTier', None))
    return payload


def claude_oauth():
    helper = Path(__file__).with_name('ClaudeRefresh')
    if helper.is_file():
        return native_claude_usage(helper)
    credentials = read_claude_credentials()
    if renew_claude_if_needed(credentials):
        credentials = read_claude_credentials()
    request = urllib.request.Request('https://api.anthropic.com/api/oauth/usage', headers={
        'Authorization': 'Bearer ' + credentials['accessToken'], 'Accept': 'application/json',
        'anthropic-beta': 'oauth-2025-04-20', 'User-Agent': 'AI-Agent-Flow/0.3.7'})
    try:
        with urllib.request.build_opener(NoRedirect()).open(request, timeout=20) as response:
            payload = json.load(response)
    except urllib.error.HTTPError as error:
        if error.code == 401:
            raise UsageError('Claude 用量服務拒絕目前憑證（HTTP 401）；若持續發生，請重新登入。') from None
        if error.code == 403:
            raise UsageError('Claude 不允許此用量查詢（HTTP 403）；不代表帳號已登出。') from None
        if error.code == 429:
            raise RateLimited(retry_after_seconds(error.headers.get('Retry-After') if error.headers else None, time.time())) from None
        raise UsageError(f'Claude 用量服務回覆 HTTP {error.code}；保留上次資料，下次更新再試。') from None
    except urllib.error.URLError as error:
        reason = error.reason
        if isinstance(reason, ssl.SSLCertVerificationError):
            message = 'Claude TLS 憑證驗證失敗；請檢查系統時間與網路憑證。'
        elif isinstance(reason, (TimeoutError, socket.timeout)):
            message = 'Claude 用量查詢逾時；不代表登出，下次更新會再試。'
        elif isinstance(reason, socket.gaierror):
            message = 'Claude 網域解析失敗；請檢查網路或 DNS。'
        else:
            message = 'Claude 用量服務連線失敗；登入狀態未確認，下次更新會再試。'
        raise UsageError(message) from None
    except (TimeoutError, socket.timeout):
        raise UsageError('Claude 用量查詢逾時；不代表登出，下次更新會再試。') from None
    except (ValueError, UnicodeError):
        raise UsageError('Claude 用量回覆不是有效 JSON；保留登入，下次更新會再試。') from None
    except OSError:
        raise UsageError('Claude 用量傳輸中斷；不代表登出，下次更新會再試。') from None
    if not isinstance(payload, dict):
        raise UsageError('Claude 用量回覆格式不符（預期物件）；保留登入，下次更新會再試。')
    payload['_plan'] = plan_label(credentials.get('subscriptionType'), credentials.get('rateLimitTier'))
    return payload


def atomic_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.usage-', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'w') as handle:
            json.dump(data, handle, ensure_ascii=False, allow_nan=False)
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def read_json(path):
    try:
        with open(path) as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def provider(key, label, rows, source, message='', updated=None, status=None, plan=None):
    return {'id': key, 'name': label, 'rows': rows, 'source': source, 'message': message,
            'plan': plan, 'updatedAt': updated, 'status': status or ('ok' if rows else 'unavailable')}


def claude_with_backoff(state, previous):
    path = state / 'claude-retry.json'
    retry = read_json(path)
    now = time.time()
    until = number(retry.get('retryAt')) or 0
    count = min(4, max(0, int(number(retry.get('failures')) or 0)))
    # Upgrade existing installations already receiving 429 without another request.
    if not retry and previous.get('message') == 'Claude 暫時限制查詢，請稍後再試。':
        count, until = 1, now + 1800
        atomic_json(path, {'failures': count, 'retryAt': until})

    def cooling(until):
        when = dt.datetime.fromtimestamp(until).astimezone().strftime('%m/%d %H:%M')
        return UsageError(f'Claude 查詢暫受限；預計 {when} 後再試，保留上次資料。')

    if now < until:
        raise cooling(until)
    try:
        payload = claude_oauth()
    except RateLimited as error:
        count = min(4, count + 1)
        delay = max(1800 * 2 ** (count - 1), number(error.retry_after) or 0)
        until = time.time() + delay
        atomic_json(path, {'failures': count, 'retryAt': until})
        raise cooling(until) from None
    atomic_json(path, {'failures': 0, 'retryAt': 0})
    return payload


def collect(state, use_claude=False):
    previous = read_json(state / 'usage.json')
    old = {p['id']: p for p in previous.get('providers', []) if isinstance(p, dict) and 'id' in p}

    def codex():
        payload = rpc_codex()
        rows = codex_rows(payload)
        return provider('codex', 'OpenAI 工作額度', rows, 'Codex',
                        'Codex・Work・Workspace Agents・Excel 共用；不含一般 Chat 聊天。', time.time(), plan=codex_plan(payload))

    def claude():
        if use_claude:
            payload = claude_with_backoff(state, old.get('claude') or {})
            rows = claude_rows(payload)
            return provider('claude', 'Claude', rows, 'Claude OAuth（非公開介面）',
                            'Claude 與 Claude Code 共用。', time.time(), plan=payload.get('_plan'))
        snapshot = read_json(state / 'claude-status.json')
        rows = claude_rows(snapshot.get('rate_limits') or {})
        updated = number(snapshot.get('updatedAt'))
        return provider('claude', 'Claude', rows, 'Claude Code 狀態列',
                        'Claude 與 Claude Code 共用。' if rows else '請連接 Claude Code，或設定狀態列來源。',
                        updated)

    def guarded(key, name, operation):
        try:
            return operation()
        except Exception as error:
            message = str(error) if isinstance(error, UsageError) else '暫時無法取得資料，請稍後重試。'
            cached = old.get(key)
            if cached and cached.get('rows'):
                return dict(cached, status='stale', message=message)
            return provider(key, name, [], '', message, status='error')

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        a = pool.submit(guarded, 'codex', 'OpenAI 工作額度', codex)
        b = pool.submit(guarded, 'claude', 'Claude', claude)
        providers = [a.result(), b.result()]
    result = {'schemaVersion': 1, 'generatedAt': time.time(), 'providers': providers}
    atomic_json(state / 'usage.json', result)
    return result


def statusline(state, payload):
    limits = payload.get('rate_limits') or {}
    safe = {}
    for key in ('five_hour', 'seven_day'):
        value = limits.get(key)
        if isinstance(value, dict):
            safe[key] = {'used_percentage': number(value.get('used_percentage')),
                         'resets_at': timestamp(value.get('resets_at'))}
    if safe:
        atomic_json(state / 'claude-status.json', {'rate_limits': safe, 'updatedAt': time.time()})
    # Deliberately do not persist the rest of the status-line payload (paths, prompts, etc.).
    return ' · '.join(f"{r['label']} 剩 {r['remainingPercent']:g}%" for r in claude_rows(safe)
                      if r['remainingPercent'] is not None) or 'Claude 額度暫無資料'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--state-dir', type=Path, default=DEFAULT_STATE)
    parser.add_argument('--claude-oauth', action='store_true')
    parser.add_argument('--statusline', action='store_true')
    args = parser.parse_args()
    if args.statusline:
        try:
            print(statusline(args.state_dir, json.load(sys.stdin)))
        except (ValueError, TypeError, AttributeError):
            print('Claude 額度暫無資料')
    else:
        print(json.dumps(collect(args.state_dir, args.claude_oauth), ensure_ascii=False, allow_nan=False))


if __name__ == '__main__':
    main()
